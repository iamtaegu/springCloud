package com.bccard.dashboard.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bccard.dashboard.dto.request.TrnsCntRequestDto;
import com.bccard.dashboard.dto.response.TrnsCntResponseDto;
import com.bccard.dashboard.service.impl.DashboardServiceONR;
import com.bccard.dashboard.service.impl.DashboardServicePURC;
import com.bccard.dashboard.service.impl.DashboardServiceUPOP;
import com.bccard.dashboard.service.impl.DashboardServiceVIP;
import com.bccard.dashboard.service.impl.DashboardServiceWISEBIZ;
import com.bccard.dashboard.service.impl.DashboardServiceACS;
import com.bccard.dashboard.service.impl.DashboardServiceAFFI;
import com.bccard.dashboard.service.impl.DashboardServiceMER;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

import javax.validation.Valid;


@RequestMapping(path = "/dash", produces = "application/json")
@CrossOrigin(origins = "*")
@RestController
@Slf4j
public class DashboardController {

	@Autowired
	private DashboardServiceONR serviceONR;
	@Autowired
	private DashboardServiceACS serviceACS;
	@Autowired
	private DashboardServiceUPOP serviceUPOP;
	@Autowired
	private DashboardServiceVIP serviceVIP;
	@Autowired
	private DashboardServiceMER serviceMER;
	@Autowired
	private DashboardServiceAFFI serviceAFFI;
	@Autowired
	private DashboardServicePURC servicePURC;
	@Autowired
	private DashboardServiceWISEBIZ serviceWISEBIZ;
	
	@GetMapping("/onr/trns/{stdYm}")
	public Flux<TrnsCntResponseDto> onrTrnsCnt(@PathVariable("stdYm") @Valid String stdYm) {
		log.info("ONR {}", stdYm);
		return serviceONR.getTrnsCnt(TrnsCntRequestDto.builder()
				.stdYm(stdYm).build());
	}
	
	@GetMapping("/acs/trns/{stdYm}")
	public Flux<TrnsCntResponseDto> acsTrnsCnt(@PathVariable("stdYm") String stdYm) {
		log.info("ACS {}", stdYm);
		return serviceACS.getTrnsCnt(TrnsCntRequestDto.builder()
				.stdYm(stdYm).build());
	}
	
	@GetMapping("/upop/trns/{stdYm}")
	public Flux<TrnsCntResponseDto> upopTrnsCnt(@PathVariable("stdYm") @Valid String stdYm) {
		log.info("UPOP {}", stdYm);
		return serviceUPOP.getTrnsCnt(TrnsCntRequestDto.builder()
				.stdYm(stdYm).build());
	}
	
	@GetMapping("/affi/trns/{stdYm}")
	public Flux<TrnsCntResponseDto> affiTrnsCnt(@PathVariable("stdYm") @Valid String stdYm) {
		log.info("AFFI {}", stdYm);
		return serviceAFFI.getTrnsCnt(TrnsCntRequestDto.builder()
				.stdYm(stdYm).build());
	}
	
	@GetMapping("/mer/trns/{stdYm}")
	public Flux<TrnsCntResponseDto> merTrnsCnt(@PathVariable("stdYm") @Valid String stdYm) {
		log.info("MER {}", stdYm);
		return serviceMER.getTrnsCnt(TrnsCntRequestDto.builder()
				.stdYm(stdYm).build());
	}
	
	@GetMapping("/vip/trns/{stdYm}")
	public Flux<TrnsCntResponseDto> vipTrnsCnt(@PathVariable("stdYm") @Valid String stdYm) {
		log.info("VIP {}", stdYm);
		return serviceVIP.getTrnsCnt(TrnsCntRequestDto.builder()
				.stdYm(stdYm).build());
	}
	
	@GetMapping("/wisebiz/trns/{stdYm}")
	public Flux<TrnsCntResponseDto> wisebizTrnsCnt(@PathVariable("stdYm") @Valid String stdYm) {
		log.info("WISEBIZ {}", stdYm);
		return serviceWISEBIZ.getTrnsCnt(TrnsCntRequestDto.builder()
				.stdYm(stdYm).build());
	}
	
	@GetMapping("/purc/trns/{stdYm}")
	public Flux<TrnsCntResponseDto> purcTrnsCnt(@PathVariable("stdYm") @Valid String stdYm) {
		log.info("PURC {}", stdYm);
		return servicePURC.getTrnsCnt(TrnsCntRequestDto.builder()
				.stdYm(stdYm).build());
	}
}