package com.bccard.dashboard.dto.persistence;

import org.springframework.data.relational.core.mapping.Column;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter 
@NoArgsConstructor 
@AllArgsConstructor
@ToString
public class TrnsCntPersistenceDto {
	@Column("stdDtm")
	private String stdDtm;
	@Column("cnt")
	private int trnsCnt;
}
