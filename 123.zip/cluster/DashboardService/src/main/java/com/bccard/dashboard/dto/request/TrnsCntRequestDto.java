package com.bccard.dashboard.dto.request;

import javax.validation.constraints.Size;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown=true)
public class TrnsCntRequestDto {
	
	@Size(min=6, max=6)
	private String stdYm;
}
