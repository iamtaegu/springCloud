package com.bccard.dashboard.mapper;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;
import com.bccard.dashboard.dto.response.TrnsCntResponseDto;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class EntityMapper {
	public static TrnsCntResponseDto mapToTrnsCntResponseDto(TrnsCntPersistenceDto persistenceDto) {		
		return new TrnsCntResponseDto(persistenceDto.getStdDtm(), persistenceDto.getTrnsCnt());
	}

}
