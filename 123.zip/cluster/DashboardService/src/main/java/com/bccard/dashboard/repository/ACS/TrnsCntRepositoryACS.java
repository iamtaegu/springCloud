package com.bccard.dashboard.repository.ACS;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;

import reactor.core.publisher.Flux;

@Repository
public interface TrnsCntRepositoryACS extends R2dbcRepository<TrnsCntPersistenceDto, String> {

	@Query("select DE_DT||substr(DE_TI,1,3) as stdDtm, COUNT(*) as cnt "
			+ "from bcdba.TDS2_RS_LOG "
			+ "where de_dt like :stdYm || '%' "
			+ "and snd_msg_tp = 'RRes' "
			+ "and tran_st = 'Y' "
			+ "group by DE_DT||substr(DE_TI,1,3) "
			+ "order by DE_DT||substr(DE_TI,1,3)")
	public Flux<TrnsCntPersistenceDto> findTrnsCntACS(String stdYm);	
}
