package com.bccard.dashboard.repository.AFFI;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;

import reactor.core.publisher.Flux;

@Repository
public interface TrnsCntRepositoryAFFI extends R2dbcRepository<TrnsCntPersistenceDto, String> {

	@Query("select trns_date||substr(trns_time, 1 , 3) as stdDtm, count(*) as cnt "
			+ "from bcdba.TBBLKCHNDLKGTRNSLOG  "
			+ "where api_req_url = 'http://130.1.3.84:8880/bccard/order/createOrder' "
			+ "and trns_date like :stdYm || '%' "
			+ "group by trns_date||substr(trns_time, 1 , 3) "
			+ "order by trns_date||substr(trns_time, 1 , 3)")
	public Flux<TrnsCntPersistenceDto> findTrnsCntAFFI(String stdYm);	
}
