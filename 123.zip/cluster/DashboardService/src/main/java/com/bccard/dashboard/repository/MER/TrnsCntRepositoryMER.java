package com.bccard.dashboard.repository.MER;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;

import reactor.core.publisher.Flux;

@Repository
public interface TrnsCntRepositoryMER extends R2dbcRepository<TrnsCntPersistenceDto, String> {

	@Query("select /*+ FULL(a) PARALLEL(a 2)*/ "
			+ "substr(a.conn_aton, 1, 11) as stdDtm, count(*) as cnt  "
			+ "from BCDBA.TBBCCARDWEBLOG a "
			+ "where a.site_clss = '31' "
			+ "and a.conn_aton like :stdYm || '%' "
			+ "and a.menu_nm in ('LoginActn')"
			+ "group by substr(a.conn_aton, 1, 11)"
			+ "order by substr(a.conn_aton, 1, 11)")
	public Flux<TrnsCntPersistenceDto> findTrnsCntMER(String stdYm);	
}
