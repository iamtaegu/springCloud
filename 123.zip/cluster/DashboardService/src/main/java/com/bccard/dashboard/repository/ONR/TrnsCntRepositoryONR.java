package com.bccard.dashboard.repository.ONR;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;

import reactor.core.publisher.Flux;

@Repository
public interface TrnsCntRepositoryONR extends R2dbcRepository<TrnsCntPersistenceDto, String> {

	@Query("select req_date||substr(req_time,1,3) as stdDtm, COUNT(*) as cnt "
			+ "from onr.tdeacclkgprfds "
			+ "where req_date like :stdYm || '%' "
			+ "and if_id = 'MCDECOOBAO00199' "
			+ "and prf_prcs_rslt_rson_no = '0000' "
			+ "group by req_date||substr(req_time,1,3) "
			+ "order by req_date||substr(req_time,1,3)")
	public Flux<TrnsCntPersistenceDto> findTrnsCntONR(String stdYm);	
}
