package com.bccard.dashboard.repository.PURC;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;

import reactor.core.publisher.Flux;

@Repository
public interface TrnsCntRepositoryPURC extends R2dbcRepository<TrnsCntPersistenceDto, String> {

	@Query("select a.sale_date, count(*) as cnt "
			+ "from bcdba.TBPPURCLST a "
			+ "where a.sale_date like :stdYm || '%' "
			+ "group by a.sale_date "
			+ "order by a.sale_date")
	public Flux<TrnsCntPersistenceDto> findTrnsCntPURC(String stdYm);
}
