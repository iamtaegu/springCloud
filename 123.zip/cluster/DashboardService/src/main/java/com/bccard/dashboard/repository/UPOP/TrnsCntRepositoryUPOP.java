package com.bccard.dashboard.repository.UPOP;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;

import reactor.core.publisher.Flux;

@Repository
public interface TrnsCntRepositoryUPOP extends R2dbcRepository<TrnsCntPersistenceDto, String> {

	@Query("select substr(auth_aton, 1, 11) as stdDtm, COUNT(*) as cnt "
			+ "from BCDBA.TBCUPOLNTRNSAUTH  "
			+ "where auth_aton like :stdYm || '%' "
			+ "and upop_trns_clss = '201' "
			+ "group by substr(auth_aton,1, 11) "
			+ "order by substr(auth_aton,1, 11)")
	public Flux<TrnsCntPersistenceDto> findTrnsCntUPOP(String stdYm);	
}
