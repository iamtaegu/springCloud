package com.bccard.dashboard.repository.VIP;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;

import reactor.core.publisher.Flux;

@Repository
public interface TrnsCntRepositoryVIP extends R2dbcRepository<TrnsCntPersistenceDto, String> {

	@Query("select aplc_date||substr(aplc_time, 1, 3) as stdDtm, COUNT(*) as cnt "
			+ "from BCDBA.TBPTEVNTREQINFO  "
			+ "where aplc_date like :stdYm || '%' "
			+ "group by aplc_date||substr(aplc_time, 1, 3) "
			+ "order by aplc_date||substr(aplc_time, 1, 3)")
	public Flux<TrnsCntPersistenceDto> findTrnsCntVIP(String stdYm);	
}
