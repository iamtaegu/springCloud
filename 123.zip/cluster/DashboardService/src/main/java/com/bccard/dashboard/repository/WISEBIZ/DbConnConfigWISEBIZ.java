package com.bccard.dashboard.repository.WISEBIZ;

import io.r2dbc.spi.ConnectionFactories;
import io.r2dbc.spi.ConnectionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.r2dbc.core.DefaultReactiveDataAccessStrategy;
import org.springframework.data.r2dbc.core.R2dbcEntityOperations;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.r2dbc.dialect.OracleDialect;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;
import org.springframework.r2dbc.core.DatabaseClient;

@Configuration
@EnableR2dbcRepositories(entityOperationsRef = "WISEBIZEntityTemplate")
public class DbConnConfigWISEBIZ {


    @Bean
    @Qualifier(value = "WISEBIZConnectionFactory")
    public ConnectionFactory WISEBIZConnectionFactory() {
    	return ConnectionFactories.get("r2dbc:oracle://carddev:carddev@172.21.212.40:1521/DCIS");
    }

    @Bean
    public R2dbcEntityOperations WISEBIZEntityTemplate(@Qualifier("WISEBIZConnectionFactory") ConnectionFactory connectionFactory) {

        DefaultReactiveDataAccessStrategy strategy = new DefaultReactiveDataAccessStrategy(OracleDialect.INSTANCE);
        DatabaseClient databaseClient = DatabaseClient.builder()
                .connectionFactory(connectionFactory)
                .bindMarkers(OracleDialect.INSTANCE.getBindMarkersFactory())
                .build();

        return new R2dbcEntityTemplate(databaseClient, strategy);
    }

}
