package com.bccard.dashboard.service;

import org.springframework.stereotype.Service;
import com.bccard.dashboard.dto.request.TrnsCntRequestDto;
import com.bccard.dashboard.dto.response.TrnsCntResponseDto;
import reactor.core.publisher.Flux;

@Service
public interface DashboardService {
	public  Flux<TrnsCntResponseDto> getTrnsCnt(TrnsCntRequestDto stdYm);
}
