package com.bccard.dashboard.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bccard.dashboard.dto.persistence.TrnsCntPersistenceDto;
import com.bccard.dashboard.dto.request.TrnsCntRequestDto;
import com.bccard.dashboard.dto.response.TrnsCntResponseDto;
import com.bccard.dashboard.repository.ONR.TrnsCntRepositoryONR;
import com.bccard.dashboard.service.DashboardService;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Flux;

@Service
public class DashboardServiceONR implements DashboardService {
	
	@Autowired
	private TrnsCntRepositoryONR repository;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	public Flux<TrnsCntResponseDto> getTrnsCnt(TrnsCntRequestDto trnsReq) {
		Flux<TrnsCntPersistenceDto> trnsPersistence = repository.findTrnsCntONR(trnsReq.getStdYm());
		return trnsPersistence.map(dto -> objectMapper.convertValue(dto, TrnsCntResponseDto.class));
	}
	
}
