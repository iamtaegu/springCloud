import React from 'react';
import './App.css';

import { Navigate, Routes, Route } from "react-router-dom";
import Paperbase from './components/Paperbase';
import NotFound from './components/NotFound';

export const DASHBOARD_MONITORING_PATH = "/DASHBOARD MONITORING";
export const MONITORING_DETAIL_PATH = "/MONITORING DETAIL";

function App() {

  return (
    <Routes>
      <Route path="/" element={<Navigate to={DASHBOARD_MONITORING_PATH} />} />
      <Route element={<Paperbase />} path={DASHBOARD_MONITORING_PATH} />
      <Route element={<Paperbase />} path={MONITORING_DETAIL_PATH} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
