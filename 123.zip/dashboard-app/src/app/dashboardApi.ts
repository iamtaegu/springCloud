import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

import * as t from "./types";

export const dashboardApi = createApi({
    reducerPath: "dashboardApi",
    baseQuery: fetchBaseQuery({
        baseUrl: "http://130.1.56.85:8080/dashboard/",
    }),
    endpoints: (builder) => ({
        getMonitorings: builder.query<t.monitoringItem[], t.SearchReqParams>({
            query: ({ search,title }) => `dash/${title}/trns/${search}`
        }),
    }),
});

export const { useGetMonitoringsQuery } = dashboardApi;