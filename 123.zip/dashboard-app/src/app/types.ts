export type SearchReqParams = {
    search: string;
    title: string;
}

export type monitoringItem = {
    stdDtm: string;
    trnsCnt: string;
}

export type monitorings = {
    message: monitoringItem[],
}
