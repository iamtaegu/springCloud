
import Plot from 'react-plotly.js';
import { useGetMonitoringsQuery } from '../../app/dashboardApi';

import Box from "@mui/material/Box";
import CircularProgress from "@mui/material/CircularProgress";

interface IProps {
    search: string,
    title: string
}

export default function MonitoringChart({ search, title }: IProps) {
    
    const { data, isLoading } = useGetMonitoringsQuery({search, title});

    if (isLoading || !data) {
        return (
            <Box sx={{ p:3, textAlign: "center"}}>
                <CircularProgress />
            </Box>
        )
    }

    const trace: Plotly.Data = {
        x: data.map((el) => el.stdDtm ? el.stdDtm.substring(4) : el.stdDtm),
        y: data.map((el) => el.trnsCnt),
        type: "scatter",
        mode: "lines",
    }

    var layout = {
        title: title + ' 모니터링', 
        autosize: true,
        xaxis: {
            type: 'category' as const,
            tickformat: 'd'
        },
    }

    return (
        <Plot 
            data = {[ trace ]}
            layout={layout}
            style={{width:"100%"}}
        /> 
    )

}
