export const getFormattedOneYearAgo = (targetDate: Date): string => {
    return (targetDate.getFullYear() - 1).toString();
}

export const getFormattedDate = (targetDate: Date): string => {
    let year = targetDate.getFullYear().toString();
    let month = (targetDate.getMonth()+1).toString();
    if (month < "10") {
        month = `0${month}`;
    }
    return `${year}${month}`;
}