import java.util.*;

public class prom1 {

    class Solution {
        /**
         * 1. put 학정번호 key, 성적 List
         *  1.1 학정번호가 없으면 List<String> create & put
         *  1.2 학정번호가 있으면 List<String> get & update
         * 2. convert Map<String, List<String>> => Map<String, String>
         *  2.1 List<String> sort(가장 좋은 성적 추출)
         * 3. sort value 기준(좋은 성적순)
         * 4. convert String[]
         */
        public String[] solution(String[] grades) {
            String[] answer = {};

            // 입력한 순서 유지(수강한 과목부터)
            Map<String, List<String>> answerListMap = new LinkedHashMap<>();
            Map<String, String> answerMap = new HashMap<>();

            distinctCreditNo(grades, answerListMap);

            convertMap(answerListMap, answerMap);

            List<Map.Entry<String, String>> sortedEntries = sortByGrade(answerMap);

            answer = new String[answerMap.size()];
            int idx = 0;
            for (Map.Entry<String, String> entry : sortedEntries) {
                answer[idx++] = entry.getKey() + " " + entry.getValue();
            }

            return answer;
        }

        private List<Map.Entry<String, String>> sortByGrade(Map<String, String> answerMap) {
            Comparator<Map.Entry<String, String>> comparator = Map.Entry.comparingByValue();
            List<Map.Entry<String, String>> sortedEntries = new ArrayList<>(answerMap.entrySet());
            sortedEntries.sort(comparator);
            return sortedEntries;
        }

        private void convertMap(Map<String, List<String>> answerListMap, Map<String, String> answerMap) {
            for (Map.Entry<String, List<String>> entry : answerListMap.entrySet()) {

                String creditNo = entry.getKey();

                List<String> gradeList = entry.getValue();
                Collections.sort(gradeList);
                String firstGrade = gradeList.get(0);

                answerMap.put(creditNo, firstGrade);
            }
        }

        private void distinctCreditNo(String[] grades, Map<String, List<String>> answerListMap) {
            for (String str : grades) {
                String creditNo = str.split(" ")[0];
                String grade = str.split(" ")[1];

                if (answerListMap.containsKey(creditNo)) {
                    List<String> mapLst = answerListMap.get(creditNo);
                    mapLst.add(grade);
                    answerListMap.put(creditNo, mapLst);
                } else {
                    List<String> lst = new ArrayList<>();
                    lst.add(grade);
                    answerListMap.put(creditNo, lst);
                }

            }
        }
    }
}
