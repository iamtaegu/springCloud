import java.util.*;

public class prom2 {

    class Solution {

        /**
         * 1. s1, s2의 값에 따른 위치맵을 생성
         * 2. s1, s2의 위치맵을 키값 기준으로 정렬
         *  ㅇ s1을 구성하는 숫자들의 위치를 뒤바꾸어 s2를 만들 수 있음
         *   - 따라서 정렬하면 s1, s2의 정렬된 키값은 같음
         * 3. s1, s2의 위치 차이에 따른 이동 횟수를 계산
         *  ㅇ 위치 차이에 따른 이동 횟수가 작다면 update
         */
        public long[] solution(int[] s1, int[] s2) {
            long[] answer = {};

            Map<Integer, List<Integer>> posMapS1 = getPosMap(s1);
            Map<Integer, List<Integer>> posMapS2 = getPosMap(s2);

            TreeMap<Integer, List<Integer>> sortedPosS1 = new TreeMap<>(posMapS1);
            TreeMap<Integer, List<Integer>> sortedPosS2 = new TreeMap<>(posMapS2);

            answer = new long[2];
            answer[1] = Long.MAX_VALUE;
            for (Map.Entry<Integer, List<Integer>> entry : sortedPosS1.entrySet()) {

                List<Integer> s1List = entry.getValue();
                List<Integer> s2List = sortedPosS2.get(entry.getKey());

                int curCount = 0;
                for (int i=0; i<s1List.size(); i++) {
                    int diff = Math.abs(s1List.get(i) - s2List.get(i));
                    curCount += diff;
                }

                if (curCount < answer[1]) {
                    answer[0] = entry.getKey().longValue();
                    answer[1] = curCount;
                }

            }

            return answer;
        }

        // 위치맵을 생성
        private Map<Integer, List<Integer>> getPosMap(int[] s) {
            Map<Integer, List<Integer>> posMapS1 = new LinkedHashMap<>();
            for (int i = 0; i< s.length; i++) {
                int keyNum = s[i];

                if (posMapS1.containsKey(keyNum)) {
                    List<Integer> mapLst = posMapS1.get(keyNum);
                    mapLst.add(i);
                    posMapS1.put(keyNum, mapLst);
                } else {
                    List<Integer> lst = new ArrayList<>();
                    lst.add(i);
                    posMapS1.put(keyNum, lst);
                }
            }
            return posMapS1;
        }

    }
}
